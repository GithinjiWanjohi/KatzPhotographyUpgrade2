<?php

$server = 'localhost';
$user = 'root';
$pass = '';
$db = 'fruitfresh';

$conn = new mysqli($server,$user,$pass,$db) or die('Could not connect');
?>